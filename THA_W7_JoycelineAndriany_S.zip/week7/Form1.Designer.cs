﻿namespace week7
{
    partial class PickMovie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cinema = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // cinema
            // 
            this.cinema.AutoSize = true;
            this.cinema.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cinema.Location = new System.Drawing.Point(304, 17);
            this.cinema.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cinema.Name = "cinema";
            this.cinema.Size = new System.Drawing.Size(548, 37);
            this.cinema.TabIndex = 0;
            this.cinema.Text = "WELCOME TO CINEMA MUZIIKKSSS";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // PickMovie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1204, 612);
            this.Controls.Add(this.cinema);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "PickMovie";
            this.Text = "Pick Movie";
            this.Load += new System.EventHandler(this.PickMovie_Load);
            this.Resize += new System.EventHandler(this.PickMovie_ReSize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label cinema;
        private System.Windows.Forms.Timer timer1;
    }
}

