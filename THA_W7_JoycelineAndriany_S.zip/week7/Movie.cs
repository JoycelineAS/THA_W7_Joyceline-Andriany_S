﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week7
{
    internal class Movie
    {

        public string title { get; set; }
        public string descr { get; set; }
        public string img { get; set; }
        public List<MovieTime> time { get; set; }
        public Movie(string title, string descr, string img)
        {
            this.title = title;
            this.descr = descr;
            this.img = img;
            this.time = new List<MovieTime>(); 
        }
    }
}
