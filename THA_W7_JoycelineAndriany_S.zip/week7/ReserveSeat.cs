﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week7
{
    internal partial class ReserveSeat : Form
    {
        TheatreManager TheatreManager { get; set; }
        MovieTime MovieTime { get; set; }
        public ReserveSeat(TheatreManager theatreManager, MovieTime movieTime)
        {
            InitializeComponent();
            this.TheatreManager = theatreManager;
            this.MovieTime = movieTime;
        }

        private void forceModeToggle(bool ignore = false){
            if (!ignore) forceMode = !forceMode;
            if (forceMode) { 
                btnForce.Text = "Force Available Mode [ON]";

                for (int i = 0; i < MovieTime.seats.Count; i++)
                {
                    List<Seat> seatList = MovieTime.seats[i];

                    for (int j = 0; j < seatList.Count; j++)
                    {
                        Seat seat = seatList[j];
                        
                        if (!seat.available)
                        {
                            seat.btn.Enabled = true;
                            seat.btn.BackColor = Color.Red;
                        }
                    }
                }
            } else
            {
                btnForce.Text = "Force Available Mode [OFF]";
                for (int i = 0; i < MovieTime.seats.Count; i++)
                {
                    List<Seat> seatList = MovieTime.seats[i];

                    for (int j = 0; j < seatList.Count; j++)
                    {
                        Seat seat = seatList[j];

                        if (!seat.available)
                        {
                            seat.btn.Enabled = false;
                            seat.btn.BackColor = Color.White;
                        }
                    }
                }
            }
        }
        bool forceMode = false;
        Button btnForce;
        List<Seat> selectedSeat = new List<Seat>();
        private void TryReserve(Seat seat) {
            if (forceMode && !seat.available)
            {
                seat.available = true;
                seat.btn.BackColor = Color.White;
            } else
            {
                if (selectedSeat.Contains(seat))
                {
                    selectedSeat.Remove(seat);
                    seat.btn.BackColor = Color.White;
                }
                else { 
                    selectedSeat.Add(seat);
                    seat.btn.BackColor = Color.Green;
                }
                refreshSelectedSeatListLabel();
            }
        }
        private void refreshSelectedSeatListLabel() 
        {
            string label = "Reserved Seat:";
            foreach (Seat seat in selectedSeat)
            {
                label += " " + seat.col + seat.row;
            }
            reserveLabel.Text = label;
        }
        private void ReserveSeat_Load(object sender, EventArgs e)
        {
            btnForce = new Button();
            btnForce.Text = "Force Available Mode [ON]";
            btnForce.Size = new Size(200, 40);
            btnForce.Location = new Point(10, 10);
            btnForce.Click += (ob, ev) => forceModeToggle();
            this.Controls.Add(btnForce);
            int X = 10 ;
            int Y = 20 + btnForce.Size.Height;
            int margin = 10;
            int size = 50;
            Point firstRowPosition = new Point();
            Point lastRowPosition = new Point();
            for (int i = 0; i < MovieTime.seats.Count; i++)
            {
                List<Seat> seatList = MovieTime.seats[i];
                
                for (int j = 0; j < seatList.Count; j++)
                {
                    Seat seat = seatList[j];
                    Button btn = new Button();
                    btn.Text = seat.col + seat.row;
                    btn.Size = new Size(50, 50);
                    btn.Location = new Point(X, Y);
                    btn.Enabled = seat.available;
                    seat.btn = btn;
                    X += size + margin;
                    btn.Click += (ob, ev) => TryReserve(seat);
                    this.Controls.Add(btn);
                    if (j == seatList.Count - 1 && i == 0)
                    {
                        firstRowPosition = new Point(btn.Location.X + size, btn.Location.Y);
                    } 
                    if (j == seatList.Count - 1 && i == seatList.Count - 1)
                    {
                        lastRowPosition = new Point(btn.Location.X + size, btn.Location.Y);
                    }
                }
                Y += size + margin;
                X = 10;
            }
            this.Height = lastRowPosition.Y+50+size;
            reserveLabel = new Label();
            reserveLabel.Text = "Reserved Seat: - ";
            reserveLabel.Location = new Point(firstRowPosition.X+20, firstRowPosition.Y);
            reserveLabel.Size = new Size(reserveLabel.Width + 50, reserveLabel.Height+100);
            this.Controls.Add(reserveLabel);
            
            Button reserveBtn = new Button();
            reserveBtn.Text = "Reserve Seat";
            reserveBtn.Location = new Point(firstRowPosition.X + 20, firstRowPosition.Y+30+100);
            reserveBtn.Size = new Size(reserveBtn.Width+50, reserveBtn.Height);
            reserveBtn.Click += (ob, ev) => reserveSelectedSeat(); 
            this.Controls.Add(reserveBtn);

            Button resetBtn = new Button();
            resetBtn.Text = "Reset";
            resetBtn.Location = new Point(firstRowPosition.X + 20, firstRowPosition.Y + 50 + 130);
            resetBtn.Size = new Size(reserveBtn.Width + 50, reserveBtn.Height);
            resetBtn.Click += (ob, ev) => resetSelectedSeat();
            this.Controls.Add(resetBtn);

        }
        private void reserveSelectedSeat() 
        {
            for (int i = selectedSeat.Count - 1; i >= 0; i--)
            {
                Seat seat = selectedSeat[i];
                seat.btn.BackColor = Color.White;
                seat.btn.Enabled = false;
                seat.available = false;
                selectedSeat.Remove(seat);

            } 
            refreshSelectedSeatListLabel();
            forceModeToggle(true);
            MessageBox.Show("Seats reserved");
        }
        private void resetSelectedSeat()
        {
            for (int i = selectedSeat.Count - 1; i >= 0; i--)
            {
                if (selectedSeat[i].btn.BackColor == Color.Red)
                {
                    selectedSeat[i].btn.BackColor = Color.White;
                    selectedSeat[i].btn.Enabled = true;
                    selectedSeat[i].available = true;
                }
            }
            refreshSelectedSeatListLabel();
        }
        
        Label reserveLabel;
    }
}
